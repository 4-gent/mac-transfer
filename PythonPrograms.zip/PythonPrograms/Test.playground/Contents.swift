//: Playground - noun: a place where people can play

import Cocoa

int main(){
    printf("HI\n");
    return 0;
}
