//: Playground - noun: a place where people can play

<?php echo "hello world";?>
