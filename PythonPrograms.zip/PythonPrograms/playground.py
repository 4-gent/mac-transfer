#File Name: playground.py
#
#This file is a workshop
#
#Author: Mj Burog

x = float(input("Enter First Number: "))
y = float(input("Enter Second Number: "))
z = x + y

print("Your input come out to a total of ")
print(z)

