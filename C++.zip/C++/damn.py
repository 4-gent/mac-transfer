import math

x = "god fucking damnit"
y = 0

while y<10:
	print(x)
	y++
print("disappointment")
