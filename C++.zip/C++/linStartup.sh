@echo off

sudo apt-get update -y

sudo apt-get full-upgrade -y

sudo apt-get install make -y && sudo apt-get install g++ -y && sudo apt-get install gcc -y

echo CPP Setup Ready
