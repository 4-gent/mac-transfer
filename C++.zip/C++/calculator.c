/*File Name: calculator.c
*
*This acts as a calculator
*
*Author: Mj Burog
*/

#include <stdio.h>
#include <string.h>

int main(){


	printf("Please input any + - / or x equations\n");
	scanf("%lf %s %lf");
	printf("Processing...\n");
	sleep(3);

	if(){
		
	}
	else if(){
		
	}
	else if (){
		
	}
	else if(){
		
	}
	else{
		printf("Cannot Process\n");
	}

return 0;
}
